#ifndef BLAS_SPARSE_H
#define BLAS_SPARSE_H

#include "blas_enum.h"
#include "blas_sparse_proto.h"

#endif
   /* BLAS_SPARSE_H */
